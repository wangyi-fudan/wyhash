#include	"parallel-hashmap/parallel_hashmap/phmap.h"
//#include	"flat_hash_map/bytell_hash_map.hpp"
#include	"wyhash/wyhash.h"
#include	"xxHash/xxhash.c"
#include	<sys/time.h>
#include	<iostream>
#include	<fstream>
#include	<sstream>
#include	<vector>
using	namespace	std;
#define	HASHMAP	phmap::flat_hash_map
//#define	HASHMAP	ska::bytell_hash_map
struct	wy{	size_t	operator()(const	string	&s)const{	return	wyhash(s.c_str(),s.size(),34432);	}};
struct	xx{	size_t	operator()(const	string	&s)const{	return	XXH64(s.c_str(),s.size(),34432);	}};
struct	xx3{	size_t	operator()(const	string	&s)const{	return	XXH3_64bits_withSeed(s.c_str(),s.size(),34432);	}};
uint64_t	bench_hash(const	char	*F,	size_t	R){
	vector<string>	v;	string	s;
	ifstream	fi(F);
	for(fi>>s;	!fi.eof();	fi>>s)	v.push_back(s);
	fi.close();
	vector<char>	u(0x1000000ull);
	cout.precision(3);	cout.setf(ios::fixed);

	timeval	beg,	end;	uint64_t	dummy=0,	N=v.size();	double	dt;
	cout<<"hash\tshort\thashmap\tbulk16M\n";
	
	for(size_t	i=0;	i<N;	i++)	dummy+=wyhash(v[i].c_str(),	v[i].size(),	0);
	gettimeofday(&beg,NULL);
	for(size_t  r=0;    r<R;    r++)	for(size_t	i=0;	i<N;	i++)	dummy+=wyhash(v[i].c_str(), v[i].size(),    r);
	gettimeofday(&end,NULL);
	dt=end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec);
	cout<<"wyhash\t"<<1e-6*R*N/dt<<"\t";

{
	HASHMAP<string,unsigned,wy>	ma;
	for(size_t	i=0;	i<N;	i++)	dummy+=ma[v[i]]++;
	gettimeofday(&beg,NULL);
	for(size_t  r=0;    r<R;    r++)	for(size_t	i=0;	i<N;	i++)	dummy+=ma[v[i]]++;
	gettimeofday(&end,NULL);
	dt=end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec);
	cout<<1e-6*R*N/dt<<"\t";
}
	dummy+=wyhash(u.data(),	u.size(),	0);
	gettimeofday(&beg,NULL);
	for(size_t	r=0;	r<R;	r++)	dummy+=wyhash(u.data(), u.size(),	r);
	gettimeofday(&end,NULL);
	dt=end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec);
	cout<<1e-9*R*u.size()/dt<<"\n";

	for(size_t	i=0;	i<N;	i++)	dummy+=XXH64(v[i].c_str(),	v[i].size(),	0);
	gettimeofday(&beg,NULL);
	for(size_t  r=0;    r<R;    r++)	for(size_t	i=0;	i<N;	i++)	dummy+=XXH64(v[i].c_str(), v[i].size(),    r);
	gettimeofday(&end,NULL);
	dt=end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec);
	cout<<"XXH64\t"<<1e-6*R*N/dt<<"\t";
{
	HASHMAP<string,unsigned,xx>	ma;
	for(size_t	i=0;	i<N;	i++)	dummy+=ma[v[i]]++;
	gettimeofday(&beg,NULL);
	for(size_t  r=0;    r<R;    r++)	for(size_t	i=0;	i<N;	i++)	dummy+=ma[v[i]]++;
	gettimeofday(&end,NULL);
	dt=end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec);
	cout<<1e-6*R*N/dt<<"\t";
}
	dummy+=XXH64(u.data(),	u.size(),	0);
	gettimeofday(&beg,NULL);
	for(size_t	r=0;	r<R;	r++)	dummy+=XXH64(u.data(), u.size(),	r);
	gettimeofday(&end,NULL);
	dt=end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec);
	cout<<1e-9*R*u.size()/dt<<"\n";

	for(size_t	i=0;	i<N;	i++)	dummy+=XXH3_64bits_withSeed(v[i].c_str(),	v[i].size(),	0);
	gettimeofday(&beg,NULL);
	for(size_t  r=0;    r<R;    r++)	for(size_t	i=0;	i<N;	i++)	dummy+=XXH3_64bits_withSeed(v[i].c_str(), v[i].size(),    r);
	gettimeofday(&end,NULL);
	dt=end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec);
	cout<<"XXH3\t"<<1e-6*R*N/dt<<"\t";
{
	HASHMAP<string,unsigned,xx3>	ma;
	for(size_t	i=0;	i<N;	i++)	dummy+=ma[v[i]]++;
	gettimeofday(&beg,NULL);
	for(size_t  r=0;    r<R;    r++)	for(size_t	i=0;	i<N;	i++)	dummy+=ma[v[i]]++;
	gettimeofday(&end,NULL);
	dt=end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec);
	cout<<1e-6*R*N/dt<<"\t";
}
	dummy+=XXH3_64bits_withSeed(u.data(),	u.size(),	0);
	gettimeofday(&beg,NULL);
	for(size_t	r=0;	r<R;	r++)	dummy+=XXH3_64bits_withSeed(u.data(), u.size(),	r);
	gettimeofday(&end,NULL);
	dt=end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec);
	cout<<1e-9*R*u.size()/dt<<"\n";

	return	dummy;
}
//#include "aesctr.h"
#include "xorshift32.h"
#include "pcg32.h"
#include "xorshift128plus.h"
#include "xorshift1024star.h"
#include "xorshift1024plus.h"
#include "xoroshiro128plus.h"
#include "splitmix64.h"
#include "pcg64.h"
#include "lehmer64.h"
#include "mersennetwister.h"
#include "mitchellmoore.h"
#include "xorshift-k4.h"
#include "xorshift-k5.h"
#include "widynski.h"
//#include "aesdragontamer.h"
#include "wyhash.h"
#include "wyrand.h"

uint64_t	bench_prng(void){
	cout.precision(5);	cout.setf(ios::fixed);
	timeval	beg,	end;	uint64_t	dummy=0,	N=0x100000000;
	gettimeofday(&beg,NULL);
	for(size_t	i=0;	i<N;	i++)	dummy+=wyrand();
	gettimeofday(&end,NULL);
	cout<<"wyrand\t"<<1e-9*N/(end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec))<<'\n';;

	gettimeofday(&beg,NULL);
	for(size_t	i=0;	i<N;	i++)	dummy+=wyhash64();
	gettimeofday(&end,NULL);
	cout<<"wyran32\t"<<1e-9*N/(end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec))<<'\n';;

	gettimeofday(&beg,NULL);
	for(size_t	i=0;	i<N;	i++)	dummy+=xorshift_k4();
	gettimeofday(&end,NULL);
	cout<<"xorshift_k4\t"<<1e-9*N/(end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec))<<'\n';;

	gettimeofday(&beg,NULL);
	for(size_t	i=0;	i<N;	i++)	dummy+=xorshift_k5();
	gettimeofday(&end,NULL);
	cout<<"xorshift_k5\t"<<1e-9*N/(end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec))<<'\n';;

	gettimeofday(&beg,NULL);
	for(size_t	i=0;	i<N;	i++)	dummy+=lehmer64();
	gettimeofday(&end,NULL);
	cout<<"lehmer64\t"<<1e-9*N/(end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec))<<'\n';;

	gettimeofday(&beg,NULL);
	for(size_t	i=0;	i<N;	i++)	dummy+=xorshift128plus();
	gettimeofday(&end,NULL);
	cout<<"xorshift128plus\t"<<1e-9*N/(end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec))<<'\n';;

	gettimeofday(&beg,NULL);
	for(size_t	i=0;	i<N;	i++)	dummy+=xoroshiro128plus();
	gettimeofday(&end,NULL);
	cout<<"xoroshiro128plus\t"<<1e-9*N/(end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec))<<'\n';;

	gettimeofday(&beg,NULL);
	for(size_t	i=0;	i<N;	i++)	dummy+=splitmix64();
	gettimeofday(&end,NULL);
	cout<<"splitmix64\t"<<1e-9*N/(end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec))<<'\n';;

	gettimeofday(&beg,NULL);
	for(size_t	i=0;	i<N;	i++)	dummy+=pcg64();
	gettimeofday(&end,NULL);
	cout<<"pcg64\t"<<1e-9*N/(end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec))<<'\n';;

	gettimeofday(&beg,NULL);
	for(size_t	i=0;	i<N;	i++)	dummy+=xorshift1024star();
	gettimeofday(&end,NULL);
	cout<<"xorshift1024star\t"<<1e-9*N/(end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec))<<'\n';;

	gettimeofday(&beg,NULL);
	for(size_t	i=0;	i<N;	i++)	dummy+=xorshift1024plus();
	gettimeofday(&end,NULL);
	cout<<"xorshift1024plus\t"<<1e-9*N/(end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec))<<'\n';;

	gettimeofday(&beg,NULL);
	for(size_t	i=0;	i<N;	i++)	dummy+=mersennetwister();
	gettimeofday(&end,NULL);
	cout<<"mersennetwister\t"<<1e-9*N/(end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec))<<'\n';;

	gettimeofday(&beg,NULL);
	for(size_t	i=0;	i<N;	i++)	dummy+=mitchellmoore();
	gettimeofday(&end,NULL);
	cout<<"mitchellmoore\t"<<1e-9*N/(end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec))<<'\n';;

	gettimeofday(&beg,NULL);
	for(size_t	i=0;	i<N;	i++)	dummy+=widynski();
	gettimeofday(&end,NULL);
	cout<<"widynski\t"<<1e-9*N/(end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec))<<'\n';;

	gettimeofday(&beg,NULL);
	for(size_t	i=0;	i<N;	i++)	dummy+=xorshift32();
	gettimeofday(&end,NULL);
	cout<<"xorshift32\t"<<1e-9*N/(end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec))<<'\n';;

	gettimeofday(&beg,NULL);
	for(size_t	i=0;	i<N;	i++)	dummy+=pcg32();
	gettimeofday(&end,NULL);
	cout<<"pcg32\t"<<1e-9*N/(end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec))<<'\n';;

	gettimeofday(&beg,NULL);
	for(size_t	i=0;	i<N;	i++)	dummy+=rand();
	gettimeofday(&end,NULL);
	cout<<"rand\t"<<1e-9*N/(end.tv_sec-beg.tv_sec+1e-6*(end.tv_usec-beg.tv_usec))<<'\n';;

	return	dummy;
}

int	main(int	ac,	char	**av){
	if(ac!=3){	cout<<"benchmark corpus repeat\n";	return	0;	}
	uint64_t	r=0;
	r+=bench_hash(av[1],atoi(av[2]));
	r+=bench_prng();
	return	r;
}
